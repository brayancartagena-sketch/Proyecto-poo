package service;

import model.Producto;

public class ProductoPrinter {

    public void imprimir(Producto producto){
        System.out.println(producto.getNombre()+producto.getPrecio());
    }

}
