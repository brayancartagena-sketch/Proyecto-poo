package model.interfaces;

public interface MetodoPago {

    void pagar(double monto);

}
