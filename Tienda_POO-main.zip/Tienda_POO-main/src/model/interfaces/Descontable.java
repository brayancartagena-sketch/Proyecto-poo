package model.interfaces;

public interface Descontable {

    double calcularDescuento(double porcentaje);

}
