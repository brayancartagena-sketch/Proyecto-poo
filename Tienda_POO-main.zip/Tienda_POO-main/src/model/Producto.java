package model;

import model.interfaces.Descontable;

public class Producto implements Descontable {

    private String nombre;
    private String talla;
    private String color;
    private String genero;
    private double precio;

    public Producto() {
    }

    public Producto(String nombre, String talla, String color, String genero, double precio) {
        this.nombre = nombre;
        this.talla = talla;
        this.color = color;
        this.genero = genero;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if(precio>=0)this.precio = precio;
    }

    @Override
    public double calcularDescuento(double porcentaje) {
        return precio-(precio*porcentaje/100);
    }
}
