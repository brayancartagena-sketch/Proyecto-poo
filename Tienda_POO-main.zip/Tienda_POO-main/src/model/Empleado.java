package model;

public class Empleado extends Persona{

    protected String cargo;

    public Empleado(String nombre, String cedula, String cargo) {
        super(nombre, cedula);
        this.cargo = cargo;
    }

    @Override
    public void mostrarRol() {
        System.out.println("Soy un empleado y mi cargo es:"+cargo);
    }
}
