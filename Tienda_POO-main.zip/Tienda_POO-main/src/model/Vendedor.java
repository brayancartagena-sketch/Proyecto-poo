package model;

public class Vendedor extends Empleado{

    public Vendedor(String nombre, String cedula) {
        super(nombre, cedula, "Vendedor");
    }

    @Override
    public void mostrarRol() {
        System.out.println("Soy un Vendedor");
    }

}
