package model;

public class Administrador extends Empleado{

    public Administrador(String nombre, String cedula) {
        super(nombre, cedula, "Admnistrador");
    }

    @Override
    public void mostrarRol() {
        System.out.println("Soy el Administrador");
    }

}
