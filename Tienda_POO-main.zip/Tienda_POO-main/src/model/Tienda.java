package model;

import java.util.ArrayList;

public class Tienda {

    private String nombre;
    private String direccion;
    private ArrayList<Producto> inventario = new ArrayList<>();

    public Tienda(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public void agregarProducto(Producto producto){
        inventario.add(producto);
    }

    public void mostrarProductos(){
        System.out.println("Inventario de la tienda:"+nombre);
        for (Producto p:inventario){
            System.out.println("Nombre:"+p.getNombre()+"Precio:"+p.getPrecio());
        }
    }

    public Producto buscarProducto(String nombre){
        for (Producto p:inventario){
            if (p.getNombre().equalsIgnoreCase(nombre)){
                return p;
            }
        }
        return null;
    }

}
