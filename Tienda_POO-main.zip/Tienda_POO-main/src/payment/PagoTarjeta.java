package payment;

import model.interfaces.MetodoPago;

public class PagoTarjeta implements MetodoPago {

    @Override
    public void pagar(double monto) {
        System.out.println("Pagando: $"+monto+"Con tarjeta");
    }

}
