import model.*;
import payment.PagoEfectivo;
import payment.PagoTarjeta;
import service.ProductoPrinter;

public class Main {
    public static void main(String[] args) {
        Tienda tienda = new Tienda("Tienda","Direccion Pr");
        Producto camisa = new Producto("camisa","M","Negro","Caballero",80000);
        Producto bermuda = new Producto("bermuda","M","Negro","Caballero",80000);
        tienda.agregarProducto(camisa);
        tienda.agregarProducto(bermuda);
        tienda.mostrarProductos();
        Producto buscar = tienda.buscarProducto(camisa.getNombre());
        if(buscar!=null){
            System.out.println("Precio con 20% de descuento:"+buscar.calcularDescuento(20));
        }
        Empleado vendedor = new Vendedor("Juan","12345");
        Empleado administrador = new Administrador("Juan","12345");

        vendedor.mostrarRol();
        administrador.mostrarRol();
    //Se usa el principio de unica responsabilidad
        ProductoPrinter imprimir = new ProductoPrinter();
        imprimir.imprimir(camisa);
        PagoTarjeta pagoTarjeta = new PagoTarjeta();
        pagoTarjeta.pagar(89900);
        PagoEfectivo pagoEfectivo = new PagoEfectivo();
        pagoEfectivo.pagar(120000);
    }
}



